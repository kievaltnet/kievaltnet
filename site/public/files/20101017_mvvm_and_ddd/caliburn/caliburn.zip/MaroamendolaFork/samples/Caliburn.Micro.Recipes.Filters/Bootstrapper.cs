﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Caliburn.Micro;
using Caliburn.Micro.Recipes.Filters.Framework;

namespace Caliburn.Micro.Recipes.Filters
{
	class Bootstrapper : Caliburn.Micro.Bootstrapper<ViewModels.CalculatorViewModel>
	{
		public Bootstrapper() {

			FilterFrameworkCoreCustomization.Hook();

		}
	}
}
