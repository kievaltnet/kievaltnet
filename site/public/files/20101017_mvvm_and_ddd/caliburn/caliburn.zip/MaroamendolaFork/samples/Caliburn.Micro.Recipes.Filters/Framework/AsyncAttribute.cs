﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Caliburn.Micro;
using System.Threading;

namespace Caliburn.Micro.Recipes.Filters.Framework
{
	/// <summary>
	/// Provides asynchronous execution of the action in a background thread
	/// </summary>
	public class AsyncAttribute : ExecutionWrapperBase
	{
		protected override void Execute(IResult inner, ActionExecutionContext context)
		{
			ThreadPool.QueueUserWorkItem(state =>
			{
				inner.Execute(context);
			});
		}

	}

	//usage:
	//[Async]
	//public void MyAction() { ... }

}
