﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using Caliburn.Micro;

namespace Caliburn.Micro.Recipes.Filters.Framework
{

	/// <summary>
	/// Updates the availability of the action (thus updating the UI)
	/// </summary>
	public class DependenciesAttribute : Attribute, IContextAware
	{

		ActionExecutionContext _context;
		INotifyPropertyChanged _inpc;

		public DependenciesAttribute(params string[] propertyNames)
		{
			PropertyNames = propertyNames ?? new string[] { };
		}

		public string[] PropertyNames { get; private set; }
		public int Priority { get; set; }



		public void MakeAwareOf(ActionExecutionContext context)
		{
			_context = context;
			_inpc = context.Target as INotifyPropertyChanged;
			if (_inpc != null)
				_inpc.PropertyChanged += inpc_PropertyChanged;
		}





		public void Dispose()
		{
			if (_inpc != null)
				_inpc.PropertyChanged -= inpc_PropertyChanged;
			_inpc = null;
		}



		void inpc_PropertyChanged(object sender, PropertyChangedEventArgs e)
		{
			if (PropertyNames.Contains(e.PropertyName))
			{
				Execute.OnUIThread(() =>
				{
					_context.Message.UpdateAvailability();
				});
			}
		}
		
	}

	//usage:
	//[Dependencies("MyProperty", "MyOtherProperty")]
	//public void DoAction() { ... }
	//public bool CanDoAction() { return MyProperty > 0 && MyOtherProperty < 1; }
}
