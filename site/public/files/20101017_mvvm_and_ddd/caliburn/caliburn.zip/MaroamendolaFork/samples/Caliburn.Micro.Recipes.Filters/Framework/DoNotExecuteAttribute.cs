﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Caliburn.Micro;

namespace Caliburn.Micro.Recipes.Filters.Framework
{
	/// <summary>
	/// Simply skip the action execution
	/// </summary>
	public class DoNotExecuteAttribute : ExecutionWrapperBase
	{
		protected override bool CanExecute(ActionExecutionContext context)
		{
			return false;
		}
	}
}
