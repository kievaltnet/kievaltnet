﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Caliburn.Micro;

namespace Caliburn.Micro.Recipes.Filters.Framework
{


	public abstract class ExecutionWrapperBase : Attribute, IExecutionWrapper, IResult
	{
		public int Priority { get; set; }

		/// <summary>
		/// Check prerequisites
		/// </summary>
		protected virtual bool CanExecute(ActionExecutionContext context) { return true;}
		/// <summary>
		/// Called just before execution (if prerequisites are met)
		/// </summary>
		protected virtual void BeforeExecute(ActionExecutionContext context) { }
		/// <summary>
		/// Called after execution (if prerequisites are met)
		/// </summary>
		protected virtual void AfterExecute(ActionExecutionContext context) { }
		/// <summary>
		/// Allows to customize the dispatch of the execution
		/// </summary>
		protected virtual void Execute(IResult inner, ActionExecutionContext context)
		{
			inner.Execute(context);
		}
		/// <summary>
		/// Called when an exception was thrown during the action execution
		/// </summary>
		protected virtual bool HandleException(ActionExecutionContext context, Exception ex) { return false; }



		IResult _inner;
		IResult IExecutionWrapper.Wrap(IResult inner)
		{
			_inner = inner;
			return this;
		}


		void IResult.Execute(ActionExecutionContext context)
		{
			if (!CanExecute(context))
			{
				_completedEvent.Invoke(this, new ResultCompletionEventArgs { WasCancelled = true });
				return;
			}


			try
			{

				EventHandler<ResultCompletionEventArgs> onCompletion = null;
				onCompletion = (o, e) =>
				{
					_inner.Completed -= onCompletion;
					AfterExecute(context);
					FinalizeExecution(context, e.WasCancelled, e.Error);
				};
				_inner.Completed += onCompletion;

				BeforeExecute(context);
				Execute(_inner, context);

			}
			catch (Exception ex)
			{
				FinalizeExecution(context, false, ex);
			}
		}

		void FinalizeExecution(ActionExecutionContext context, bool wasCancelled, Exception ex)
		{
			if (ex != null && HandleException(context, ex))
				ex = null;

			_completedEvent.Invoke(this, new ResultCompletionEventArgs { WasCancelled = wasCancelled, Error = ex });
		}

		event EventHandler<ResultCompletionEventArgs> _completedEvent = delegate { };
		event EventHandler<ResultCompletionEventArgs> IResult.Completed
		{
			add { _completedEvent += value; }
			remove { _completedEvent -= value; }
		}
	}
}
