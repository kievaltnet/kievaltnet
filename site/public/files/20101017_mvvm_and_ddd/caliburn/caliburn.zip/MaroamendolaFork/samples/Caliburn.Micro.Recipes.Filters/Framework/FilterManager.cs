﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using Caliburn.Micro;

namespace Caliburn.Micro.Recipes.Filters.Framework
{

	public static class FilterManager
	{

		public static IResult WrapWith(this IResult inner, IEnumerable<IExecutionWrapper> wrappers)
		{
			IResult previous = inner;
			foreach (var wrapper in wrappers)
			{
				previous = wrapper.Wrap(previous);
			}
			return previous;
		}

		
		public static Func<ActionExecutionContext, IEnumerable<IFilter>> GetFiltersFor = (context) => { 
			//TODO: apply caching?
			return context.Target.GetType().GetAttributes<IFilter>(true)
					.Union(context.Method.GetAttributes<IFilter>(true))
					.OrderBy(x => x.Priority);
		};
		 
	}
}
