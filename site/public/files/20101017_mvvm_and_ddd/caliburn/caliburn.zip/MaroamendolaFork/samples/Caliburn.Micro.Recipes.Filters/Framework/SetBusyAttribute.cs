﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Caliburn.Micro;

namespace Caliburn.Micro.Recipes.Filters.Framework
{
	/// <summary>
	/// Sets "IsBusy" property to true (on models implementing ICanBeBusy) during the execution
	/// </summary>
	public class SetBusyAttribute : ExecutionWrapperBase
	{
		protected override void BeforeExecute(ActionExecutionContext context)
		{
			SetBusy(context.Target as ICanBeBusy, true);
		}
		protected override void AfterExecute(ActionExecutionContext context)
		{
			SetBusy(context.Target as ICanBeBusy, false);
		}
		protected override bool HandleException(ActionExecutionContext context, Exception ex)
		{
			SetBusy(context.Target as ICanBeBusy, false);
			return false;
		}

		private void SetBusy(ICanBeBusy model, bool isBusy)
		{
			if (model != null)
				model.IsBusy = isBusy;
		}

	}
	//usage:
	//[SetBusy]
	//[Async] //prevents UI freezing, thus allowing busy state representation
	//public void VeryLongAction() { ... }
}
