﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

namespace Caliburn.Micro.Recipes.Filters.Results
{
	public class MessageBoxResult: IResult
	{
		string _message;
		public MessageBoxResult(string message)
		{
			_message = message;
		}

		public void Execute(ActionExecutionContext context)
		{
			MessageBox.Show(_message);
			Completed(this, new ResultCompletionEventArgs());
		}

		public event EventHandler<ResultCompletionEventArgs> Completed = delegate { };

		
	}
}
