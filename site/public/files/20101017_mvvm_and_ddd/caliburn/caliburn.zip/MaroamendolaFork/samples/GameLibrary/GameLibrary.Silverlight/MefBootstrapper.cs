﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Caliburn.Micro;
using GameLibrary.Framework;
using System.Collections.Generic;
using GameLibrary.ViewModels;
using System.Linq;
using System.ComponentModel.Composition.Hosting;
using System.ComponentModel.Composition.Primitives;
using System.ComponentModel.Composition;

namespace GameLibrary
{
	public class MefBootstrapper : Bootstrapper<IShell>
	{
		private CompositionContainer container;

		public MefBootstrapper()
		{
			LogManager.GetLog = type => new DebugLog(type);

			var @base = ViewLocator.LocateForModelType;
			ViewLocator.LocateForModelType = (modelType, displayLocation, context) =>
			{
				if (modelType.Equals(typeof(GameLibrary.Model.GameDTO)))
					return new GameLibrary.Views.GameView();
				else
					return @base(modelType, displayLocation, context);
			};

			ConventionManager.AddElementConvention<Rating>(Rating.ValueProperty, "Value", "ValueChanged");
		}


		protected override void Configure()
		{
			container = CompositionHost.Initialize(
				new AggregateCatalog(
					AssemblySource.Instance.Select(x => new AssemblyCatalog(x)).OfType<ComposablePartCatalog>()
					)
				);
			
			var batch = new CompositionBatch();
			batch.AddExportedValue(container);
			batch.AddExportedValue<IWindowManager>(new WindowManager());
			container.Compose(batch);
		}

		protected override object GetInstance(Type serviceType, string key)
		{
			string contract = string.IsNullOrEmpty(key) ? AttributedModelServices.GetContractName(serviceType) : key;
			var exports = container.GetExportedValues<object>(contract);

			if (exports.Count() > 0)
				return exports.First();

			throw new Exception(string.Format("Could not locate any instances of contract {0}.", contract));
		}

		protected override IEnumerable<object> GetAllInstances(Type serviceType)
		{
			return container.GetExportedValues<object>(AttributedModelServices.GetContractName(serviceType));
		}

		protected override void BuildUp(object instance)
		{
			container.SatisfyImportsOnce(instance);
		}
	}
}
