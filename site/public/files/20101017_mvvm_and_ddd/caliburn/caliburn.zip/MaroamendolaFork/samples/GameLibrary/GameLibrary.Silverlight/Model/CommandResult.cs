﻿ 

namespace GameLibrary.Model
{
    using System;
	using Caliburn.Micro;
	using System.ComponentModel.Composition;

    public class CommandResult : IResult
    {
		[Import]
		public IBackend Bus { get; set; }

        public ICommand Command { get; private set; }

        public CommandResult(ICommand command)
        {
            Command = command;
        }

		public void Execute(ActionExecutionContext context)
        {
            Bus.Send(Command);
            Completed(this, new ResultCompletionEventArgs());
        }

        public event EventHandler<ResultCompletionEventArgs> Completed = delegate { }; 
    }
}