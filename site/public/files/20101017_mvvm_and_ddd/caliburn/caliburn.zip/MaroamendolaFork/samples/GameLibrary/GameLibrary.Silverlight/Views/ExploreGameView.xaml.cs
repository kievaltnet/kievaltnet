﻿namespace GameLibrary.Views
{
    using System.Windows.Controls;

    public partial class ExploreGameView : UserControl
    {
        public ExploreGameView()
        {
            InitializeComponent();
        }
    }
}