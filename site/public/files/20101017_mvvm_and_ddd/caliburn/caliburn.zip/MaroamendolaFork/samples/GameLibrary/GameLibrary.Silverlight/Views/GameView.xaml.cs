﻿namespace GameLibrary.Views
{
    using System.Windows.Controls;

    public partial class GameView : UserControl
    {
        public GameView()
        {
            InitializeComponent();
        }
    }
}