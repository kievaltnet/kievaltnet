﻿namespace GameLibrary.Views
{
    using System.Windows.Controls;

    public partial class ResultsView : UserControl
    {
        public ResultsView()
        {
            InitializeComponent();
        }
    }
}