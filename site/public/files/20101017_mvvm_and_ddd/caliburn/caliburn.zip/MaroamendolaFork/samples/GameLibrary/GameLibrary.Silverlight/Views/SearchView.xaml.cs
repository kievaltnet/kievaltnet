﻿namespace GameLibrary.Views
{
    using System.Windows.Controls;

    public partial class SearchView : UserControl
    {
        public SearchView()
        {
            InitializeComponent();
        }
    }
}