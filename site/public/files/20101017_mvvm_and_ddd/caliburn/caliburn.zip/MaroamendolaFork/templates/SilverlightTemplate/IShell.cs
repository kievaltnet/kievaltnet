﻿namespace SilverlightTemplate
{
	public interface IShell
	{
		
	}
}