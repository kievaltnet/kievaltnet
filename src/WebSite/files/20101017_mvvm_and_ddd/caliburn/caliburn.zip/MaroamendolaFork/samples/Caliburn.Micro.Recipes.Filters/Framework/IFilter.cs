﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using Caliburn.Micro;

namespace Caliburn.Micro.Recipes.Filters.Framework
{
	public interface IFilter
	{
		int Priority { get; }
	}

	public interface IExecutionWrapper : IFilter
	{
		IResult Wrap(IResult inner);
	}

	public interface IContextAware : IFilter, IDisposable
	{
		void MakeAwareOf(ActionExecutionContext context);
	}
}
