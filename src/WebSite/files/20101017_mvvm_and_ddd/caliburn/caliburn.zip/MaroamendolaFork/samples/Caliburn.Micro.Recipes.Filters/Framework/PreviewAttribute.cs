﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using Caliburn.Micro;

namespace Caliburn.Micro.Recipes.Filters.Framework
{
	/// <summary>
	/// Allows to specify a guard method or property with an arbitrary name
	/// </summary>
	public class PreviewAttribute : Attribute, IContextAware
	{

		public PreviewAttribute(string methodName)
		{
			MethodName = methodName;
		}

		public string MethodName { get; private set; }
		public int Priority { get; set; }


		public void MakeAwareOf(ActionExecutionContext context)
		{
			var targetType = context.Target.GetType();
            var guard = targetType.GetMethod(MethodName);
			if (guard== null)
				guard = targetType.GetMethod("get_" + MethodName);

			if (guard == null) return;

			var oldCanExecute = context.CanExecute;
			context.CanExecute = () =>
			{
				if (!oldCanExecute()) return false;

				return (bool)guard.Invoke(
					context.Target,
					MessageBinder.DetermineParameters(context, guard.GetParameters())	
				);
			};
		}

		public void Dispose() { }

	}
	//usage:
	//[Preview("IsMyActionAvailable")]
	//public void MyAction(int value) { ... }
	//public bool IsMyActionAvailable(int value) { ... }
}
