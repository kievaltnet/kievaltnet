﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Caliburn.Micro;
using Caliburn.Micro.Recipes.Filters.Framework;
using System.Threading;
using System.Windows;

namespace Caliburn.Micro.Recipes.Filters.ViewModels
{
	public class CalculatorViewModel : Screen, ICanBeBusy
	{

		bool _IsBusy;
		public bool IsBusy
		{
			get { return _IsBusy; }
			set { _IsBusy = value; NotifyOfPropertyChange(() => IsBusy); }
		}

		double _A;
		public double A
		{
			get { return _A; }
			set
			{
				_A = value;
				NotifyOfPropertyChange(() => A);
				NotifyOfPropertyChange(() => CanDivide);
			}
		}

		double _B;
		public double B
		{
			get { return _B; }
			set
			{
				_B = value;
				NotifyOfPropertyChange(() => B);
				NotifyOfPropertyChange(() => CanDivide);
			}
		}

		double _Result;
		public double Result
		{
			get { return _Result; }
			set { _Result = value; NotifyOfPropertyChange(() => Result); }
		}

		public bool Rescue(Exception ex) {
			MessageBox.Show(ex.ToString());
			return true;
		}




		public bool CanDivide
		{
			get { return B != 0; }
		}

		
		public void Divide()
		{
			Result = A / B;

		}

		
		[DoNotExecute]
		public void SkippedDivide()
		{
			Result = A / B;
		}

		[SetBusy]
		[Async]
		[Preview("CanDivide")]
		[Dependencies("B")]
		public void VerySlowDivide()
		{
			Thread.Sleep(2000);
			Result = A / B;
		}

		[Rescue]
		public void ThrowingDivide()
		{
			throw new NotImplementedException();
		}

		[Preview("CanDivide")]
		public void NotUpdatedDivide()
		{
			
		}


		[Preview("CanDivide")]
		[Dependencies("B")]
		public IEnumerable<IResult> ChattyDivide() {

			yield return new Results.MessageBoxResult("I'm about to execute division");
			yield return new Results.MessageBoxResult("Let me think a bit more");

			Result = A / B;

			yield return new Results.MessageBoxResult("I'm done");
		}

	}
}
