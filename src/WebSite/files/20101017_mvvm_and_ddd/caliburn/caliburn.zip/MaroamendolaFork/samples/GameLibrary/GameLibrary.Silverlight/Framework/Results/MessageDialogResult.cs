using System;
using System.Diagnostics.Contracts;
using System.Windows;
using Caliburn.Micro;

namespace GameLibrary.Framework.Results
{
    public class MessageDialogResult : IResult
    {
        public MessageDialogResult(string text)
        {
            Text = text;
        }

        public MessageDialogResult(string text, string caption, MessageBoxButton button) : this(text)
        {
            Contract.Requires(caption != null);

            Caption = caption;
            Button = button;
        }

        public string Text { get; private set; }
        
        public string Caption { get; private set; }

        public MessageBoxButton Button { get; private set; }

        public MessageBoxResult Result { get; set; }

        public void Execute(ActionExecutionContext context)
        {
            this.Result = Caption != null 
                ? MessageBox.Show(this.Text, this.Caption, this.Button) 
                : MessageBox.Show(this.Text);

            Caliburn.Micro.Execute.OnUIThread(() => Completed(this, new ResultCompletionEventArgs()));
        }

        public event EventHandler<ResultCompletionEventArgs> Completed = delegate { };
    }
}