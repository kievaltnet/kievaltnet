﻿namespace GameLibrary.Framework.Results
{
    using System;
    using Caliburn.Micro;

    public class OpenChildResult<TChild> : IResult
    {
        private Func<ActionExecutionContext, IConductor> _locateParent;

        private readonly Func<ActionExecutionContext, TChild> _locateChild = 
            c => IoC.Get<TChild>();

        public OpenChildResult() {}

        public OpenChildResult(TChild child)
        {
            _locateChild = c => child;
        }

        public Action<TChild> OnConfigure { get; set; }

        public OpenChildResult<TChild> In<TParent>()
            where TParent : IConductor
        {
            _locateParent = c => IoC.Get<TParent>();
            return this;
        }

        public OpenChildResult<TChild> In(IConductor parent)
        {
            _locateParent = c => parent;
            return this;
        }

		public OpenChildResult<TChild> Configured(Action<TChild> configure)
        {
			OnConfigure = configure;   
            return this;
        }

		public void Execute(ActionExecutionContext context)
        {
            if(_locateParent == null)
                _locateParent = c => (IConductor)c.Target;

            var parent = _locateParent(context);
            var child = _locateChild(context);

			if(OnConfigure != null)
                OnConfigure(child);
            
            parent.ActivateItem(child);
			Completed(this, new ResultCompletionEventArgs ());
            
        }

        

		public event EventHandler<ResultCompletionEventArgs> Completed = delegate { };
    }
}