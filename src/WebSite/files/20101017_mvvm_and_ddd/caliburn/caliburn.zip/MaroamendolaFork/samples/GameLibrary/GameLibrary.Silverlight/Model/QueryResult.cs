﻿namespace GameLibrary.Model
{
    using System;
    using Caliburn.Micro;
	using System.ComponentModel.Composition;

    public class QueryResult<TResponse> : IResult
    {
		[Import]
		public IBackend Bus { get; set; }

        public QueryResult(IQuery<TResponse> query)
        {
            Query = query;
        }

        public TResponse Response { get; set; }

        public IQuery<TResponse> Query { get; private set; }

        public void Execute(ActionExecutionContext context)
        {
            Bus.Send(Query, response => {
                Response = response;
                Caliburn.Micro.Execute.OnUIThread(() => Completed(this, new ResultCompletionEventArgs()));
            });
        }

        public event EventHandler<ResultCompletionEventArgs> Completed = delegate { };
    }
}