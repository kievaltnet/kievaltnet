﻿

namespace GameLibrary.ViewModels
{
	using GameLibrary.Framework;
	using Caliburn.Micro;
	using GameLibrary.Framework.Results;
	using System.ComponentModel.Composition;

	[Export(typeof(NoResultsViewModel))]
	public class NoResultsViewModel
	{
		private string _searchText;

		public IResult AddGame()
		{
			return Show.Child<AddGameViewModel>()
				.In<IShell>()
				.Configured(x => x.Title = _searchText);
		}

		public NoResultsViewModel WithTitle(string searchText)
		{
			_searchText = searchText;
			return this;
		}
	}
}