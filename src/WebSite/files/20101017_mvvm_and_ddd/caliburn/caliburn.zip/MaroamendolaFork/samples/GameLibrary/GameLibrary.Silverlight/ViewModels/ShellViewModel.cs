﻿namespace GameLibrary.ViewModels
{
    using System.Collections.Generic;
    using Caliburn.Micro;
	using GameLibrary.Framework;
	using GameLibrary.Framework.Results;
	using System.ComponentModel.Composition;


	[Export(typeof(IShell))]
    public class ShellViewModel : Conductor<IScreen>, IShell
    {
		SearchViewModel _firstScreen;

		[ImportingConstructor]
		public ShellViewModel(SearchViewModel firstScreen) {
			_firstScreen = firstScreen;
		}

		protected override void OnInitialize()
		{
			base.OnInitialize();
			ActivateItem(_firstScreen);
		}
		
		public IEnumerable<IResult> Back()
        {
            yield return Show.Child<SearchViewModel>().In<IShell>();
        }
    }
}