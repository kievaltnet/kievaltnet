﻿namespace GameLibrary.Views
{
    using System.Windows.Controls;

    public partial class AddGameView : UserControl
    {
        public AddGameView()
        {
            InitializeComponent();
        }
    }
}