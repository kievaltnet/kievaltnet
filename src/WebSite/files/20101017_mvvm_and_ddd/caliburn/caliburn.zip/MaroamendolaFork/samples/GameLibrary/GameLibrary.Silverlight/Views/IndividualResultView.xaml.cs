﻿namespace GameLibrary.Views
{
    using System.Windows.Controls;

    public partial class IndividualResultView : UserControl
    {
        public IndividualResultView()
        {
            InitializeComponent();
        }
    }
}