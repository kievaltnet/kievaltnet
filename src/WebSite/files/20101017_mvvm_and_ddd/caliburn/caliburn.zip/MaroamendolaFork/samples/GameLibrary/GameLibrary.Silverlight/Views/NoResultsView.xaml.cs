﻿namespace GameLibrary.Views
{
    using System.Windows.Controls;

    public partial class NoResultsView : UserControl
    {
        public NoResultsView()
        {
            InitializeComponent();
        }
    }
}