﻿using System.Windows.Controls;

namespace GameLibrary.Views
{
    public partial class ShellView : UserControl
    {
        public ShellView()
        {
            InitializeComponent();
        }
    }
}