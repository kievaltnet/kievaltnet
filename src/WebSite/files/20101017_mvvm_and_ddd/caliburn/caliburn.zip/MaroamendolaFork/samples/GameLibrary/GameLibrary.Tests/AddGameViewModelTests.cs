﻿using System.Windows;
using GameLibrary.Framework;
using GameLibrary.Framework.Results;
using GameLibrary.Model;
using GameLibrary.ViewModels;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GameLibrary.Tests
{
    [TestClass]
    public class AddGameViewModelTests
    {
        private static readonly string EmptyNote = string.Empty;

        private AddGameViewModel vw;
        private CoroutineEnumerator coroutines;

        [TestInitialize]
        public void SetUp()
        {
            IValidator nullValidator = null;
            this.vw = new AddGameViewModel(nullValidator);
            this.vw.Title = "Civ 2";
            this.vw.Notes = EmptyNote;

            coroutines = new CoroutineEnumerator(this.vw.AddGame());
        }

        [TestCleanup]
        public void TearDown()
        {
            coroutines.Finish();
        }

        [TestMethod]
        public void AddGame_EmptyNotes_ShouldAskToConfirm()
        {
            var messageBox = coroutines.Next<MessageDialogResult>();
            Assert.AreEqual(
                "Are you going to add Game without notes?",
                messageBox.Text);
        }

        [TestMethod]
        public void AddGame_EmptyNotesConfirmed_ShouldAddGameAndReturnToSearchScreen()
        {
            var messageBox = coroutines.Next<MessageDialogResult>();
            messageBox.Result = MessageBoxResult.OK;

            var addGameToLibrary = coroutines.Next<CommandResult>();
            Assert.IsInstanceOfType(addGameToLibrary.Command, typeof(AddGameToLibrary));
            
            // May check that command properties are valid

            coroutines.Next<OpenChildResult<SearchViewModel>>();
        }

        [TestMethod]
        public void AddGame_EmptyNotesDiscarded_ShouldContinueEditing()
        {
            var messageBox = coroutines.Next<MessageDialogResult>();
            messageBox.Result = MessageBoxResult.Cancel;
            coroutines.ShouldBeFinished();
        }
    }
}