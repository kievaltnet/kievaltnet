using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GameLibrary.Tests
{
    public static class CoroutineAssertions
    {
        public static void ShouldBeFinished(this CoroutineEnumerator coroutines)
        {
            Assert.AreEqual(0, coroutines.Finish());
        }
    }
}