using System;
using System.Collections.Generic;
using Caliburn.Micro;

namespace GameLibrary.Tests
{
    public class CoroutineEnumerator
    {
        private readonly IEnumerator<IResult> enumerator;

        public CoroutineEnumerator(IEnumerable<IResult> enumerable)
        {
            this.enumerator = enumerable.GetEnumerator();
        }

        public CoroutineEnumerator(IEnumerator<IResult> enumerator)
        {
            this.enumerator = enumerator;
        }

        public TCoroutine Next<TCoroutine>()
        {
            return (TCoroutine)Next(typeof (TCoroutine));
        }

        public object Next(Type type)
        {
            while (enumerator.MoveNext())
            {
                if (enumerator.Current.GetType() == type)
                {
                    return enumerator.Current;
                }
            }

            throw new InvalidOperationException("List of coroutines does not include " + type.Name);
        }

        public int Finish()
        {
            var i = 0;
            while (enumerator.MoveNext())
            {
                i++;
            }

            return i;
        }
    }
}