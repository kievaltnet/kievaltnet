﻿using System;
using System.Collections.Generic;
using GameLibrary.Framework.Results;
using GameLibrary.Model;
using GameLibrary.ViewModels;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GameLibrary.Tests
{
    [TestClass]
    public class SearchViewModelTests
    {
        private const string SearchCriteria = "Game name";
        private SearchViewModel vw;
        private CoroutineEnumerator coroutines;

        [TestInitialize]
        public void SetUp()
        {
            this.vw = new SearchViewModel(new NoResultsViewModel(), new ResultsViewModel());
            this.vw.SearchText = SearchCriteria;

            coroutines = new CoroutineEnumerator(this.vw.ExecuteSearch());
        }

        [TestCleanup]
        public void TearDown()
        {
            coroutines.Finish();
        }

        [TestMethod]
        public void Search_WhenOneGameFoundWithNameMatchingSearchText_ShouldShowGameDetails()
        {
            // Search for games.
            var search = coroutines.Next<QueryResult<IEnumerable<SearchResult>>>();

            // Simulate that only one game found and it's name 
            // is the same as search criteria
            var gameFound = new SearchResult
                            {
                                Id = Guid.NewGuid(),
                                Title = SearchCriteria
                            };

            search.Response = new List<SearchResult> { gameFound };

            // Ensure that a query for this particular game is sent
            var getGame = coroutines.Next<QueryResult<GameDTO>>();
            Assert.AreEqual(
                gameFound.Id,
                ((GetGame)getGame.Query).Id,
                "Should use the same Id within GetGame query");

            // Stub query result with a fake game.
            var gameDetails = FakeAGameDto();
            getGame.Response = gameDetails;

            // Ensure that game details screen opened
            var showGameDetails = coroutines.Next<OpenChildResult<ExploreGameViewModel>>();

            // And that that found game was passed to the game details view model.
            var detailsViewModel = new ExploreGameViewModel();
            showGameDetails.OnConfigure(detailsViewModel);
            Assert.AreSame(gameDetails, detailsViewModel.Game);
        }

        private static GameDTO FakeAGameDto()
        {
            return new GameDTO();
        }
    }
}