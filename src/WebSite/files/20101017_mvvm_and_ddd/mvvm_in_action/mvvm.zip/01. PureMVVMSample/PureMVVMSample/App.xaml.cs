﻿using System.Windows;

namespace PureMVVMSample
{
    public partial class App : Application
    {
        private void Application_Startup(object sender, StartupEventArgs e)
        {
            var viewModel = new MainViewModel(new DataProvider());

            var mainWindow = new MainWindow
            {
                DataContext = viewModel
            };

            Current.MainWindow = mainWindow;
            mainWindow.Show();
        }
    }
}
