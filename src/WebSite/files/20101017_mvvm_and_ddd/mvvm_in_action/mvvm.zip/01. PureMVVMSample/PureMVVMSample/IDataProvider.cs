﻿using System.Collections.Generic;

namespace PureMVVMSample
{
    internal interface IDataProvider
    {
        IEnumerable<string> Tags { get; }
    }
}
