﻿using System.Windows;

namespace ViewModelFirstSample
{
    public partial class App : Application
    {
        private void Application_Startup(object sender, StartupEventArgs e)
        {
            var mainWindow = new MainWindow();
            Current.MainWindow = mainWindow;

            var viewModel = new MainViewModel(new DataProvider(), mainWindow);

            mainWindow.DataContext = viewModel;
            mainWindow.Show();
        }
    }
}
