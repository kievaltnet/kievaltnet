﻿using System.Collections.Generic;

namespace ViewModelFirstSample
{
    internal interface IDataProvider
    {
        IEnumerable<string> Tags { get; }
    }
}
