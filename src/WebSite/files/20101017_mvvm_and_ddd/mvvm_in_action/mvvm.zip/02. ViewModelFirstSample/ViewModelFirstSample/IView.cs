﻿namespace ViewModelFirstSample
{
    internal interface IView
    {
        void SetReadyState();
    }
}
