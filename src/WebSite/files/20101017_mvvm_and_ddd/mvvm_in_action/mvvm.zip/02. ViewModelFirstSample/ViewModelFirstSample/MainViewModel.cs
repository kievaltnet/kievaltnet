﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Input;

namespace ViewModelFirstSample
{
    internal sealed class MainViewModel : INotifyPropertyChanged
    {
        private IView _view;

        public MainViewModel(IDataProvider provider, IView view)
        {
            Tags = new ObservableCollection<string>(provider.Tags);
            _view = view;
        }

        public ObservableCollection<string> Tags
        {
            get;
            private set;
        }

        private string _newTag;
        public string NewTag
        {
            get { return _newTag; }
            set
            {
                if (value != _newTag)
                {
                    _newTag = value;
                    OnPropertyChanged("NewTag");
                }
            }
        }

        public ICommand _addNewTagCommand;
        public ICommand AddNewTagCommand
        {
            get
            {
                if (_addNewTagCommand == null)
                    _addNewTagCommand = new CustomCommand(this);

                return _addNewTagCommand;
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private class CustomCommand : ICommand
        {
            private MainViewModel _viewModel;

            public CustomCommand(MainViewModel viewModel)
            {
                _viewModel = viewModel;
            }

            public bool CanExecute(object parameter)
            {
                return
                    !string.IsNullOrEmpty(_viewModel.NewTag) &&
                    !_viewModel.Tags.Contains(_viewModel.NewTag);
            }

            public event EventHandler CanExecuteChanged
            {
                add { CommandManager.RequerySuggested += value; }
                remove { CommandManager.RequerySuggested -= value; }
            }

            public void Execute(object parameter)
            {
                _viewModel.Tags.Add(_viewModel.NewTag);
                _viewModel.NewTag = string.Empty;

                _viewModel._view.SetReadyState();
            }
        }
    }
}
