﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace ViewModelFirstSample
{
    public partial class MainWindow : Window, IView
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public void SetReadyState()
        {
            TagsListView.SelectedIndex = GetFirstVisible(TagsListView) + 3;
        }

        private int GetFirstVisible(ListBox listBox)
        {
            ListBoxItem firstItem =
                listBox.ItemContainerGenerator.ContainerFromIndex(0) as ListBoxItem;

            VirtualizingStackPanel panel =
                (VirtualizingStackPanel)VisualTreeHelper.GetParent(firstItem);

            return (int)panel.VerticalOffset;
        }
    }
}
