﻿namespace MvvmLightDemo
{
    public interface IView
    {
        void SetReadyState();
    }
}
