﻿using System.Collections.Generic;

namespace MvvmLightDemo.Model
{
    public interface IDataProvider
    {
        IEnumerable<string> Tags { get; }
    }
}
