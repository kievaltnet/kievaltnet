﻿using System.Collections.ObjectModel;
using System.Windows.Input;

using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;

using MvvmLightDemo.Model;

namespace MvvmLightDemo.ViewModel
{
    public sealed class MainViewModel : ViewModelBase
    {
        public MainViewModel(IDataProvider provider)
        {
            Tags = new ObservableCollection<string>(provider.Tags);
        }

        public ObservableCollection<string> Tags
        {
            get;
            private set;
        }

        private string _newTag;
        public string NewTag
        {
            get { return _newTag; }
            set
            {
                if (value != _newTag)
                {
                    _newTag = value;
                    RaisePropertyChanged("NewTag");
                }
            }
        }

        public ICommand _addNewTagCommand;
        public ICommand AddNewTagCommand
        {
            get
            {
                if (_addNewTagCommand == null)
                    _addNewTagCommand = new RelayCommand(AddNewTagExecute);

                return _addNewTagCommand;
            }
        }

        public void AddNewTagExecute()
        {
            Tags.Add(NewTag);
            NewTag = string.Empty;
        }
    }
}