﻿using System.Collections.Generic;

namespace DataTemplatesDemo.Model
{
    public interface IDataProvider
    {
        IEnumerable<TagInfo> Tags { get; }
    }
}
