﻿namespace DataTemplatesDemo.Model
{
    public sealed class TagInfo
    {
        public string Name { get; set; }
        public int Score { get; set; }
    }
}
