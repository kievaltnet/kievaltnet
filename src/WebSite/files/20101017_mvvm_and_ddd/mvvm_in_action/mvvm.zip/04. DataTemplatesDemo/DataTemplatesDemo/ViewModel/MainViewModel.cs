﻿using System.Collections.ObjectModel;
using System.Windows.Input;

using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;

using DataTemplatesDemo.Model;

namespace DataTemplatesDemo.ViewModel
{
    public class MainViewModel : ViewModelBase
    {
        public MainViewModel(IDataProvider provider)
        {
            Tags = new ObservableCollection<TagInfo>(provider.Tags);
        }

        public ObservableCollection<TagInfo> Tags
        {
            get;
            private set;
        }

        private string _newTagName;
        public string NewTagName
        {
            get { return _newTagName; }
            set
            {
                if (value != _newTagName)
                {
                    _newTagName = value;
                    RaisePropertyChanged("NewTagName");
                }
            }
        }

        public ICommand _addNewTagCommand;
        public ICommand AddNewTagCommand
        {
            get
            {
                if (_addNewTagCommand == null)
                    _addNewTagCommand = new RelayCommand(AddNewTagExecute, AddNewTagCanExecute);

                return _addNewTagCommand;
            }
        }

        public void AddNewTagExecute()
        {
            Tags.Add(new TagInfo { Name = NewTagName, Score = 0 });
            NewTagName = string.Empty;
        }

        public bool AddNewTagCanExecute()
        {
            return !string.IsNullOrEmpty(NewTagName);
        }
    }
}