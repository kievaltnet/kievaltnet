﻿using System.Collections.Generic;

namespace MultipleViewsDemo.Model
{
    internal sealed class DataProvider : IDataProvider
    {
        public IEnumerable<string> Tags
        {
            get
            {
                return new List<string>
                {
                    "c#",
                    "java",
                    "php",
                    ".net",
                    "javascript",
                    "asp.net",
                    "jquery",
                    "c++",
                    "iphone",
                    "python",
                    "sql",
                    "mysql",
                    "html",
                    "ruby-on-rails"
                };
            }
        }
    }
}
