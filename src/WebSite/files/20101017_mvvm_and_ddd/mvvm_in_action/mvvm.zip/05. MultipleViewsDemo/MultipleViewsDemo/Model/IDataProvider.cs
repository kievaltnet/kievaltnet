﻿using System.Collections.Generic;

namespace MultipleViewsDemo.Model
{
    public interface IDataProvider
    {
        IEnumerable<string> Tags { get; }
    }
}
