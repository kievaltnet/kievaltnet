﻿using System.Globalization;
using System.Windows.Data;
using System;

namespace MultipleVMDemo
{
    public sealed class BoolToColorConverter : IValueConverter
    {

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            bool isEditMode = (bool)value;

            return isEditMode ? "Red" : "Green";

        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }
}
