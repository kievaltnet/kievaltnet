﻿using System.Windows;

using MultipleVMDemo.ViewModel;

namespace MultipleVMDemo
{
    /// <summary>
    /// This application's main window.
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly DetailsWindow _detailesWindow = new DetailsWindow();
        private readonly NewTagWindow _newTagWindow = new NewTagWindow();

        /// <summary>
        /// Initializes a new instance of the MainWindow class.
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();

            Closing += (s, e) =>
            {
                _detailesWindow.Close();
                _newTagWindow.Close();

                ViewModelLocator.Cleanup();
            };
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            _detailesWindow.Show();

            _newTagWindow.DataContext = new NewTagViewModel();
            _newTagWindow.Show();
        }
    }
}