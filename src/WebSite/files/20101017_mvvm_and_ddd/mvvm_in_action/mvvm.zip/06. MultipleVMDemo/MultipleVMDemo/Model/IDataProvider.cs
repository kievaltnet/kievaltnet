﻿using System.Collections.Generic;

namespace MultipleVMDemo.Model
{
    public interface IDataProvider
    {
        IEnumerable<TagInfo> Tags { get; }
    }
}
