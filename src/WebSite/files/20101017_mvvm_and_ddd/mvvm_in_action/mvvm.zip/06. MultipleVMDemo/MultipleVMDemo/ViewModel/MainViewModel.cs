﻿using System.Collections.ObjectModel;
using System.Windows.Input;

using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;

using MultipleVMDemo.Model;
using GalaSoft.MvvmLight.Messaging;

namespace MultipleVMDemo.ViewModel
{
    public class MainViewModel : ViewModelBase
    {
        public MainViewModel(IDataProvider provider)
        {
            Tags = new ObservableCollection<TagInfo>(provider.Tags);

            Messenger.Default.Register<bool>(this, 123, // token
                x =>
                {
                    IsEditMode = x;
                });

            Messenger.Default.Register<TagInfo>(this,
                x =>
                {
                    Tags.Add(x);
                });
        }

        public ObservableCollection<TagInfo> Tags
        {
            get;
            private set;
        }

        private bool _isEditMode;
        public bool IsEditMode
        {
            get { return _isEditMode; }
            set
            {
                if (_isEditMode != value)
                {
                    _isEditMode = value;
                    RaisePropertyChanged("IsEditMode");
                }
            }
        }

        private string _newTagName;
        public string NewTagName
        {
            get { return _newTagName; }
            set
            {
                if (value != _newTagName)
                {
                    _newTagName = value;
                    RaisePropertyChanged("NewTagName");
                }
            }
        }
    }
}