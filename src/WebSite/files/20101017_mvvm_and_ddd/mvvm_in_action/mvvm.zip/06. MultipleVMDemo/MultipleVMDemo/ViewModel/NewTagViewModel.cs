﻿using System.Windows.Input;

using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using GalaSoft.MvvmLight.Messaging;
using GalaSoft.MvvmLight.Threading;

using MultipleVMDemo.Model;
using System.Threading;
using System;

namespace MultipleVMDemo.ViewModel
{
    public sealed class NewTagViewModel : ViewModelBase
    {
        private string _tagName;
        public string TagName
        {
            get { return _tagName; }
            set
            {
                if (_tagName != value)
                {
                    _tagName = value;
                    RaisePropertyChanged("TagName");
                }
            }
        }

        private int _tagScore;
        public int TagScore
        {
            get { return _tagScore; }
            set
            {
                if (_tagScore != value)
                {
                    _tagScore = value;
                    RaisePropertyChanged("TagScore");
                }
            }
        }

        private ICommand _addNewTagCommand;
        public ICommand AddNewTag
        {
            get
            {
                if (_addNewTagCommand == null)
                    _addNewTagCommand = new RelayCommand(AddNewTagExecute, AddNewTagCanExecute);

                return _addNewTagCommand;
            }
        }

        public void AddNewTagExecute()
        {
            Messenger.Default.Send<TagInfo, MainViewModel>(
                new TagInfo
                {
                    Name = TagName,
                    Score = TagScore
                });

            TagName = string.Empty;
            TagScore = 0;
        }

        public bool AddNewTagCanExecute()
        {
            return !string.IsNullOrEmpty(TagName);
        }

        private ICommand _changeModeCommand;
        public ICommand ChangeMode
        {
            get
            {
                if (_changeModeCommand == null)
                    _changeModeCommand = new RelayCommand(ChangeModeExecute);

                return _changeModeCommand;
            }
        }

        public void ChangeModeExecute()
        {
            Messenger.Default.Send(
                !string.IsNullOrEmpty(TagName), 123);
        }

        private ICommand _generateNewTagCommand;
        public ICommand GenerateNewTag
        {
            get
            {
                if (_generateNewTagCommand == null)
                    _generateNewTagCommand = new RelayCommand(GenerateNewTagExecute);

                return _generateNewTagCommand;
            }
        }

        public void GenerateNewTagExecute()
        {
            new Action(GenerateTag).BeginInvoke(null, null);
        }

        private void GenerateTag()
        {
            Thread.Sleep(5000);

            DispatcherHelper.CheckBeginInvokeOnUI(
                () =>
                {
                    Messenger.Default.Send<TagInfo, MainViewModel>(
                        new TagInfo
                        {
                            Name = DateTime.Now.ToLongTimeString(),
                            Score = 1
                        });
                }
            );
        }
    }
}
